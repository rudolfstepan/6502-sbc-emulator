# Sheet64 cc65 Source

This directory contains the clean machine-code version of Sheet64 for the
6502 SBC FPGA/emulator target. It uses the FPGA 80-column text mode and
provides an A1-H16 sheet with a green retro-monitor color scheme.

Build from the repository root:

```sh
make spreadsheet
```

Outputs:

- `data/disk/spreadsheet.prg`
- `data/sdcard/spreadsheet.d64`
- staged copies below `bin/data/`

The PRG is linked at `$1000` and begins with a normal two-byte PRG load header.
It is not tokenized BASIC. Drag and drop `data/disk/spreadsheet.prg` into the
emulator to start it directly. On startup it shows a welcome screen with the
program title and `written by stepan.science`; press any key to enter the sheet.

Controls:

- Cursor keys - move the selected cell
- Return - edit the selected cell
- `N` - new sheet
- `L` - load saved RAM snapshot
- `S` - save RAM snapshot
- `?` - help
- `R` - recalculate
- `C` - clear all cells
- `Q` - quit

Cell input:

- `12` - integer number
- `12,5` - decimal number with comma
- `PARTS` - text
- `'123` - force numeric-looking text
- `=A1+B1` - formula

Source files:

- `spreadsheet.c` - spreadsheet UI, formulas, cell storage, screen drawing
- `sbc6502_io.s` - FPGA kernel keyboard/character wrappers
- `prg_header.s` - two-byte PRG load header
- `spreadsheet.cfg` - cc65/ld65 memory layout
