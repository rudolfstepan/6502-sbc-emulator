/*
 * Sheet64 for the 6502 SBC FPGA build.
 *
 * This is a real cc65/cl65 PRG, not a tokenized BASIC wrapper. The program
 * starts at $1000, reads raw keys from the VIA keyboard port, and draws
 * directly into the VIC 80-column text RAM.
 */

#define SCREEN_W 80
#define SCREEN_H 25
#define ROWS 16
#define COLS 8
#define CELLS (ROWS * COLS)
#define CELL_W 9
#define TEXT_LEN 13
#define MENU_Y 1
#define RULE_Y 2
#define HEADER_Y 3
#define GRID_Y 4
#define STATUS_Y 20
#define PROMPT_Y 21

#define SCREEN ((unsigned char*)0x8000)
#define VIC_MODE (*(unsigned char*)0x9000)
#define VIC_CX   (*(unsigned char*)0x9001)
#define VIC_CY   (*(unsigned char*)0x9002)
#define VIC_FG   (*(unsigned char*)0x9003)
#define VIC_BG   (*(unsigned char*)0x9004)
#define VIC_ATTR (*(unsigned char*)0x9005)
#define VIC_SX   (*(unsigned char*)0x900D)
#define VIC_SY   (*(unsigned char*)0x900E)
#define VIA_DDRA (*(unsigned char*)0x8803)

#define COLOR_GREEN 5
#define COLOR_LIGHT_GREEN 13

#define KEY_DOWN  0x11
#define KEY_RIGHT 0x1D
#define KEY_UP    0x91
#define KEY_LEFT  0x9D

unsigned char sbc_getch(void);
void __fastcall__ sbc_putch(unsigned char ch);

static long value[CELLS];
static unsigned char kind[CELLS];
static char text[CELLS][TEXT_LEN];
static long saved_value[CELLS];
static unsigned char saved_kind[CELLS];
static char saved_text[CELLS][TEXT_LEN];
static char input[TEXT_LEN];
static unsigned char selected_row;
static unsigned char selected_col;
static unsigned char have_saved_sheet;

static unsigned char upcase(unsigned char ch)
{
    if (ch >= 'a' && ch <= 'z') {
        return ch - 32;
    }
    return ch;
}

static unsigned char str_len(const char *s)
{
    unsigned char n;
    n = 0;
    while (s[n] != 0) {
        ++n;
    }
    return n;
}

static void str_copy(char *dst, const char *src, unsigned char max)
{
    unsigned char i;
    i = 0;
    while (i + 1 < max && src[i] != 0) {
        dst[i] = src[i];
        ++i;
    }
    dst[i] = 0;
}

static void clear_line(unsigned char y)
{
    unsigned char x;
    for (x = 0; x < SCREEN_W; ++x) {
        SCREEN[y * SCREEN_W + x] = ' ';
    }
}

static void put_at(unsigned char x, unsigned char y, unsigned char ch)
{
    if (x < SCREEN_W && y < SCREEN_H) {
        SCREEN[y * SCREEN_W + x] = ch;
    }
}

static void print_at(unsigned char x, unsigned char y, const char *s)
{
    while (*s != 0 && x < SCREEN_W) {
        put_at(x, y, (unsigned char)*s);
        ++x;
        ++s;
    }
}

static void center_at(unsigned char y, const char *s)
{
    unsigned char len;
    len = str_len(s);
    if (len >= SCREEN_W) {
        print_at(0, y, s);
    } else {
        print_at((SCREEN_W - len) / 2, y, s);
    }
}

static void clear_screen(void)
{
    unsigned int i;
    VIC_MODE = 0;
    VIC_ATTR = 2;
    VIC_FG = COLOR_LIGHT_GREEN;
    VIC_BG = COLOR_GREEN;
    VIC_CX = 0;
    VIC_CY = 0;
    VIC_SX = 0;
    VIC_SY = 0;
    for (i = 0; i < 2000; ++i) {
        SCREEN[i] = ' ';
    }
}

static void draw_welcome(void)
{
    clear_screen();
    center_at(5,  "****************************************");
    center_at(7,  "SHEET80");
    center_at(9,  "SPREADSHEET FOR THE 6502 SBC");
    center_at(11, "WRITTEN BY STEPAN.SCIENCE");
    center_at(14, "A1-H16  80 COLUMN EDITION");
    center_at(17, "PRESS ANY KEY TO START");
    center_at(19, "2026");
    center_at(21, "****************************************");
    VIC_CX = 0;
    VIC_CY = 17;
}

static unsigned char is_digit(unsigned char ch)
{
    return ch >= '0' && ch <= '9';
}

static unsigned char is_number_text(const char *s)
{
    unsigned char i;
    unsigned char digits;
    unsigned char comma;

    i = 0;
    digits = 0;
    comma = 0;
    if (s[0] == '-' || s[0] == '+') {
        i = 1;
    }
    while (s[i] != 0) {
        if (is_digit((unsigned char)s[i])) {
            digits = 1;
        } else if ((s[i] == ',' || s[i] == '.') && comma == 0) {
            comma = 1;
        } else {
            return 0;
        }
        ++i;
    }
    return digits;
}

static void fixed_to_str(long n, char *out)
{
    char tmp[12];
    unsigned char p;
    unsigned char i;
    unsigned char neg;
    unsigned char cents;
    long whole;

    p = 0;
    i = 0;
    neg = 0;
    if (n < 0) {
        neg = 1;
        n = -n;
    }
    cents = (unsigned char)(n % 100);
    whole = n / 100;
    do {
        tmp[p++] = (char)('0' + (whole % 10));
        whole = whole / 10;
    } while (whole != 0 && p < sizeof(tmp));
    if (neg != 0) {
        out[i++] = '-';
    }
    while (p != 0) {
        out[i++] = tmp[--p];
    }
    if (cents != 0) {
        out[i++] = ',';
        out[i++] = (char)('0' + (cents / 10));
        if ((cents % 10) != 0) {
            out[i++] = (char)('0' + (cents % 10));
        }
    }
    out[i] = 0;
}

static long parse_number(const char *s)
{
    long n;
    long cents;
    unsigned char i;
    unsigned char neg;
    unsigned char cent_digits;

    n = 0;
    cents = 0;
    i = 0;
    neg = 0;
    cent_digits = 0;
    if (s[0] == '-' || s[0] == '+') {
        if (s[0] == '-') {
            neg = 1;
        }
        i = 1;
    }
    while (is_digit((unsigned char)s[i])) {
        n = (n * 10) + (s[i] - '0');
        ++i;
    }
    if (s[i] == ',' || s[i] == '.') {
        ++i;
        while (is_digit((unsigned char)s[i]) && cent_digits < 2) {
            cents = (cents * 10) + (s[i] - '0');
            ++cent_digits;
            ++i;
        }
    }
    if (cent_digits == 1) {
        cents *= 10;
    }
    n = (n * 100) + cents;
    return neg ? -n : n;
}

static signed char parse_cell(const char *s)
{
    unsigned char col;
    unsigned char row;

    if (s[0] < 'A' || s[0] > ('A' + COLS - 1)) {
        return -1;
    }
    col = s[0] - 'A';
    if (s[1] < '1' || s[1] > '9') {
        return -1;
    }
    row = s[1] - '0';
    if (s[2] >= '0' && s[2] <= '9') {
        row = (row * 10) + (s[2] - '0');
    }
    if (row < 1 || row > ROWS) {
        return -1;
    }
    return (signed char)((row - 1) * COLS + col);
}

static long eval_operand(const char *s)
{
    signed char cell;
    cell = parse_cell(s);
    if (cell >= 0) {
        return value[(unsigned char)cell];
    }
    if (is_number_text(s)) {
        return parse_number(s);
    }
    return 0;
}

static long eval_formula(const char *s)
{
    char left[TEXT_LEN];
    char right[TEXT_LEN];
    unsigned char i;
    unsigned char op_pos;
    char op;
    long a;
    long b;

    op_pos = 0;
    op = 0;
    i = 0;
    while (s[i] != 0) {
        if (i != 0 && (s[i] == '+' || s[i] == '-' || s[i] == '*' || s[i] == '/')) {
            op_pos = i;
            op = s[i];
            break;
        }
        ++i;
    }
    if (op == 0) {
        return eval_operand(s);
    }
    for (i = 0; i < op_pos && i + 1 < TEXT_LEN; ++i) {
        left[i] = s[i];
    }
    left[i] = 0;
    str_copy(right, s + op_pos + 1, TEXT_LEN);
    a = eval_operand(left);
    b = eval_operand(right);
    if (op == '+') {
        return a + b;
    }
    if (op == '-') {
        return a - b;
    }
    if (op == '*') {
        return (a * b) / 100;
    }
    if (op == '/' && b != 0) {
        return (a * 100) / b;
    }
    return 0;
}

static void recalc(void)
{
    unsigned char pass;
    unsigned char i;
    for (pass = 0; pass < 3; ++pass) {
        for (i = 0; i < CELLS; ++i) {
            if (kind[i] == 1) {
                if (text[i][0] == '=') {
                    value[i] = eval_formula(text[i] + 1);
                } else {
                    value[i] = parse_number(text[i]);
                }
            }
        }
    }
}

static void cell_display(unsigned char i, char *out)
{
    if (kind[i] == 0) {
        out[0] = 0;
    } else if (kind[i] == 2) {
        str_copy(out, text[i], TEXT_LEN);
    } else {
        fixed_to_str(value[i], out);
    }
}

static void print_cell(unsigned char i, unsigned char x, unsigned char y, unsigned char selected)
{
    char out[TEXT_LEN];
    unsigned char n;
    unsigned char j;
    unsigned char max_content;

    cell_display(i, out);
    n = str_len(out);
    max_content = selected ? CELL_W - 2 : CELL_W;
    if (n > max_content) {
        n = max_content;
    }
    if (selected) {
        put_at(x, y, '[');
        for (j = 0; j < max_content; ++j) {
            put_at(x + 1 + j, y, j < n ? (unsigned char)out[j] : ' ');
        }
        put_at(x + CELL_W - 1, y, ']');
    } else {
        for (j = 0; j < CELL_W; ++j) {
            put_at(x + j, y, j < n ? (unsigned char)out[j] : ' ');
        }
    }
}

static void draw_sheet(void)
{
    unsigned char r;
    unsigned char c;
    unsigned char i;

    clear_screen();
    print_at(0, 0, "SHEET80 C65  A1-H16");
    print_at(0, MENU_Y, "N NEW  L LOAD  S SAVE  R RECALC  C CLEAR  ? HELP  Q QUIT");
    for (c = 0; c < SCREEN_W; ++c) {
        put_at(c, RULE_Y, '-');
    }
    for (c = 0; c < COLS; ++c) {
        put_at(5 + c * CELL_W, HEADER_Y, (unsigned char)('A' + c));
    }
    for (r = 0; r < ROWS; ++r) {
        if (r + 1 < 10) {
            put_at(1, GRID_Y + r, (unsigned char)('1' + r));
        } else {
            put_at(0, GRID_Y + r, (unsigned char)('0' + ((r + 1) / 10)));
            put_at(1, GRID_Y + r, (unsigned char)('0' + ((r + 1) % 10)));
        }
        for (c = 0; c < COLS; ++c) {
            i = r * COLS + c;
            print_cell(i, 5 + c * CELL_W, GRID_Y + r,
                       (r == selected_row && c == selected_col) ? 1 : 0);
        }
    }
    print_at(0, STATUS_Y, "SELECTED ");
    put_at(9, STATUS_Y, (unsigned char)('A' + selected_col));
    if (selected_row + 1 < 10) {
        put_at(10, STATUS_Y, (unsigned char)('1' + selected_row));
    } else {
        put_at(10, STATUS_Y, (unsigned char)('0' + ((selected_row + 1) / 10)));
        put_at(11, STATUS_Y, (unsigned char)('0' + ((selected_row + 1) % 10)));
    }
    print_at(0, PROMPT_Y, "CURSORS MOVE  RETURN EDIT");
    VIC_CX = 5 + selected_col * CELL_W;
    VIC_CY = GRID_Y + selected_row;
}

static void read_line(unsigned char x, unsigned char y, char *buf,
                      unsigned char max, const char *initial)
{
    unsigned char pos;
    unsigned char ch;

    pos = 0;
    buf[0] = 0;
    while (initial[pos] != 0 && pos + 1 < max) {
        buf[pos] = initial[pos];
        put_at(x + pos, y, (unsigned char)initial[pos]);
        ++pos;
    }
    buf[pos] = 0;
    put_at(x + pos, y, '_');
    VIC_CX = x + pos;
    VIC_CY = y;
    while (1) {
        ch = sbc_getch();
        if (ch == 13 || ch == 10) {
            put_at(x + pos, y, ' ');
            buf[pos] = 0;
            return;
        }
        if (ch == 8 || ch == 20 || ch == 127) {
            if (pos != 0) {
                put_at(x + pos, y, ' ');
                --pos;
                put_at(x + pos, y, '_');
                VIC_CX = x + pos;
                VIC_CY = y;
            }
        } else if (ch >= 32 && ch < 127 && pos + 1 < max) {
            ch = upcase(ch);
            buf[pos] = (char)ch;
            put_at(x + pos, y, ch);
            ++pos;
            put_at(x + pos, y, '_');
            VIC_CX = x + pos;
            VIC_CY = y;
        }
    }
}

static void prompt_line(const char *msg)
{
    clear_line(PROMPT_Y);
    clear_line(PROMPT_Y + 1);
    clear_line(PROMPT_Y + 2);
    print_at(0, PROMPT_Y, msg);
}

static void status_message(const char *msg)
{
    prompt_line(msg);
}

static void wait_return(void)
{
    prompt_line("PRESS RETURN ");
    read_line(13, PROMPT_Y, input, TEXT_LEN, "");
}

static void show_help(void)
{
    clear_screen();
    print_at(0, 0, "SHEET80 COMMANDS");
    print_at(0, 2, "CURSORS MOVE CELL");
    print_at(0, 3, "RETURN  EDIT CELL");
    print_at(0, 4, "N       NEW SHEET");
    print_at(0, 5, "L       LOAD SAVED RAM SNAPSHOT");
    print_at(0, 6, "S       SAVE RAM SNAPSHOT");
    print_at(0, 7, "R       RECALC");
    print_at(0, 8, "C       CLEAR SHEET");
    print_at(0, 9, "Q       QUIT");
    print_at(0, 11, "CELL CONTENT:");
    print_at(0, 12, "12          NUMBER");
    print_at(0, 13, "12,5        DECIMAL NUMBER");
    print_at(0, 14, "PARTS       TEXT");
    print_at(0, 15, "'123        TEXT FORCED");
    print_at(0, 16, "=A1+B1      FORMULA");
    print_at(0, 17, "=A1-B1 =A1*B1 =A1/B1");
    print_at(0, 19, "NO SPACES INSIDE FORMULAS.");
    wait_return();
}

static void clear_cells(void)
{
    unsigned char i;
    for (i = 0; i < CELLS; ++i) {
        value[i] = 0;
        kind[i] = 0;
        text[i][0] = 0;
    }
}

static void new_sheet(void)
{
    selected_row = 0;
    selected_col = 0;
    clear_cells();
}

static void save_sheet(void)
{
    unsigned char i;
    unsigned char j;

    for (i = 0; i < CELLS; ++i) {
        saved_value[i] = value[i];
        saved_kind[i] = kind[i];
        for (j = 0; j < TEXT_LEN; ++j) {
            saved_text[i][j] = text[i][j];
        }
    }
    have_saved_sheet = 1;
}

static unsigned char load_sheet(void)
{
    unsigned char i;
    unsigned char j;

    if (have_saved_sheet == 0) {
        return 0;
    }
    for (i = 0; i < CELLS; ++i) {
        value[i] = saved_value[i];
        kind[i] = saved_kind[i];
        for (j = 0; j < TEXT_LEN; ++j) {
            text[i][j] = saved_text[i][j];
        }
    }
    recalc();
    return 1;
}

static void edit_cell(unsigned char i)
{
    prompt_line("VALUE ");
    put_at(6, PROMPT_Y, (unsigned char)('A' + (i % COLS)));
    if ((i / COLS) + 1 < 10) {
        put_at(7, PROMPT_Y, (unsigned char)('1' + (i / COLS)));
        print_at(8, PROMPT_Y, " = ");
        read_line(11, PROMPT_Y, input, TEXT_LEN, kind[i] == 0 ? "" : text[i]);
    } else {
        put_at(7, PROMPT_Y, (unsigned char)('0' + (((i / COLS) + 1) / 10)));
        put_at(8, PROMPT_Y, (unsigned char)('0' + (((i / COLS) + 1) % 10)));
        print_at(9, PROMPT_Y, " = ");
        read_line(12, PROMPT_Y, input, TEXT_LEN, kind[i] == 0 ? "" : text[i]);
    }
    if (input[0] == 0) {
        text[i][0] = 0;
        kind[i] = 0;
        value[i] = 0;
    } else if (input[0] == '\'') {
        str_copy(text[i], input + 1, TEXT_LEN);
        kind[i] = 2;
    } else if (input[0] == '=') {
        str_copy(text[i], input, TEXT_LEN);
        kind[i] = 1;
    } else if (is_number_text(input)) {
        str_copy(text[i], input, TEXT_LEN);
        kind[i] = 1;
    } else {
        str_copy(text[i], input, TEXT_LEN);
        kind[i] = 2;
    }
    recalc();
}

void main(void)
{
    unsigned char ch;

    VIA_DDRA = 0;
    draw_welcome();
    (void)sbc_getch();
    have_saved_sheet = 0;
    selected_row = 0;
    selected_col = 0;
    clear_cells();
    draw_sheet();
    while (1) {
        ch = upcase(sbc_getch());
        if (ch == KEY_LEFT) {
            if (selected_col != 0) {
                --selected_col;
                draw_sheet();
            }
        } else if (ch == KEY_RIGHT) {
            if (selected_col + 1 < COLS) {
                ++selected_col;
                draw_sheet();
            }
        } else if (ch == KEY_UP) {
            if (selected_row != 0) {
                --selected_row;
                draw_sheet();
            }
        } else if (ch == KEY_DOWN) {
            if (selected_row + 1 < ROWS) {
                ++selected_row;
                draw_sheet();
            }
        } else if (ch == 13 || ch == 10) {
            edit_cell((unsigned char)(selected_row * COLS + selected_col));
            draw_sheet();
        } else if (ch == 'Q') {
            clear_screen();
            print_at(0, 0, "SHEET64 ENDED");
            while (1) {
            }
        } else if (ch == '?') {
            show_help();
            draw_sheet();
        } else if (ch == 'N') {
            new_sheet();
            draw_sheet();
            status_message("NEW SHEET");
        } else if (ch == 'L') {
            if (load_sheet()) {
                draw_sheet();
                status_message("LOADED RAM SNAPSHOT");
            } else {
                draw_sheet();
                status_message("NO SAVED SNAPSHOT");
            }
        } else if (ch == 'S') {
            save_sheet();
            draw_sheet();
            status_message("SAVED RAM SNAPSHOT");
        } else if (ch == 'R') {
            recalc();
            draw_sheet();
            status_message("RECALCULATED");
        } else if (ch == 'C') {
            clear_cells();
            draw_sheet();
            status_message("CLEARED");
        }
    }
}
