.export _sbc_getch
.export _sbc_putch

KERNAL_CHROUT   = $C00C
VIA_ORA         = $8801
VIA_IFR         = $880D
VIA_CA1_BIT     = $02

.segment "CODE"

; unsigned char sbc_getch(void)
; Blocks until the VIA keyboard buffer has a raw byte available. We avoid the
; FPGA kernel screen editor here because it consumes cursor keys itself.
_sbc_getch:
@wait:
    lda VIA_IFR
    and #VIA_CA1_BIT
    beq @wait
    lda VIA_ORA
    ldx #$00
    rts

; void __fastcall__ sbc_putch(unsigned char ch)
; Not used by the sheet UI yet, but handy while developing/debugging.
_sbc_putch:
    jmp KERNAL_CHROUT
